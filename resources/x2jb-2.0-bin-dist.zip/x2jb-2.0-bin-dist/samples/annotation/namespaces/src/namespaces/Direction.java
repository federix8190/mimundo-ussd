/*
 * XML 2 Java Binding (X2JB) - the excellent Java tool.
 * Copyright 2009, by Richard Opalka.
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not see the FSF site:
 * http://www.fsf.org/ and search for the LGPL License document there.
 */
package namespaces;

import org.x2jb.bind.BindingException;

/**
 * Namespaces sample
 * @author <a href="mailto:richard_opalka@yahoo.com">Richard Opalka</a>
 */
public final class Direction
{

    public static final Direction IN = new Direction( "IN" );

    public static final Direction OUT = new Direction( "OUT" );

    public static final Direction IN_OUT = new Direction( "IN OUT" );

    private final String type;

    private Direction( final String t )
    {
        super();
        this.type = t;
    }

    /**
     * Factory method which converts passed <code>String</code> to <code>Direction</code> object
     * @param s to be converted
     * @return <code>Direction</code> instance
     */
    public static Direction valueOf( final String s )
    {
        if ( s != null )
        {
            final String directionType = s.toUpperCase();
            final boolean containsIn = directionType.indexOf( Direction.IN.toString() ) != -1;
            final boolean containsOut = directionType.indexOf( Direction.OUT.toString() ) != -1;

            if ( containsIn && containsOut )
            {
                return Direction.IN_OUT;
            }
            if ( containsIn )
            {
                return Direction.IN;
            }
            if ( containsOut )
            {
                return Direction.OUT;
            }
        }

        throw new BindingException( "Value '" + s + "' has incorrect direction value" );
    }

    public String toString()
    {
        return this.type;
    }

}
