/*
 * XML 2 Java Binding (X2JB) - the excellent Java tool.
 * Copyright 2009, by Richard Opalka.
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not see the FSF site:
 * http://www.fsf.org/ and search for the LGPL License document there.
 */
package namespaces;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import namespaces.ifaces.InterceptorConfig;
import namespaces.ifaces.ModuleConfig;
import namespaces.ifaces.ServerConfig;
import namespaces.ifaces.TransportConfig;

import org.w3c.dom.Document;
import org.x2jb.bind.XML2Java;

/**
 * Namespaces sample
 * @author <a href="mailto:richard_opalka@yahoo.com">Richard Opalka</a>
 */
public final class Main
{

    private Main()
    {
        super();
    }

    /**
     * Lookups specified resource on the classpath and returns parsed document instance
     * @param classpath resource to return
     */
    private static Document getDocument( final String resource ) throws Exception
    {
        Document retVal = null;
        try
        {
            final DocumentBuilderFactory builderFactory = DocumentBuilderFactory.newInstance();
            builderFactory.setNamespaceAware( true );
            builderFactory.setIgnoringComments( true );
            final DocumentBuilder builder = builderFactory.newDocumentBuilder();
            retVal = builder.parse( Main.class.getResourceAsStream( resource ) );
        }
        catch ( ParserConfigurationException e )
        {
            e.printStackTrace( System.err );
            System.exit( 1 );
        }
        return retVal;
    }

    public static void main( final String[] args ) throws Exception
    {
        final Document parsedDocument = Main.getDocument( "/server.xml" );
        final ServerConfig config = XML2Java.bind( parsedDocument, ServerConfig.class );

        final ModuleConfig[] modules = config.getRegisteredModules();

        System.out.println();
        System.out.println( "Registered server modules: " );
        System.out.println();
        for ( int i = 0; i < modules.length; i++ )
        {
            System.out.println( "Module name: " + modules[ i ].getName() );
            System.out.println( "Module class: " + modules[ i ].getClassName() );
            final InterceptorConfig[] interceptorConfigs = modules[ i ].getInterceptors();
            final TransportConfig[] transportConfigs = modules[ i ].getTransports();

            if ( interceptorConfigs.length > 0 )
            {
                // print out interceptor repository configuration
                System.out.println();
                System.out.println( "  Registered interceptors: " );
                System.out.println();
                for ( int j = 0; j < interceptorConfigs.length; j++ )
                {
                    final InterceptorConfig ic = interceptorConfigs[ j ];
                    System.out.println( "    Name: " + ic.getName() );
                    System.out.println( "    Class: " + ic.getClassName() );
                    System.out.println( "    Direction: " + ic.getDirection() );
                    System.out.println();
                }
            }

            if ( transportConfigs.length > 0 )
            {
                // print out transport repository configuration
                System.out.println();
                System.out.println( "  Registered transports: " );
                System.out.println();
                for ( int j = 0; j < transportConfigs.length; j++ )
                {
                    final TransportConfig tc = transportConfigs[ j ];
                    System.out.println( "    Name: " + tc.getName() );
                    System.out.println( "    Class: " + tc.getClassName() );
                    System.out.println( "    Protocol: " + tc.getProtocol() );
                    System.out.println( "    Port: " + tc.getPort() );
                    System.out.println( "    Max threads count: " + tc.getMaxThreads() );
                    System.out.println( "    Connection timeout: " + tc.getConnectionTimeout() );
                    System.out.println();
                }
            }

            System.out.println();
        }
    }

}
