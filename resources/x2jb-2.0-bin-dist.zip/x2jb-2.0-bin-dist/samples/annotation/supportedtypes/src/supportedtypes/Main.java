/*
 * XML 2 Java Binding (X2JB) - the excellent Java tool.
 * Copyright 2009, by Richard Opalka.
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not see the FSF site:
 * http://www.fsf.org/ and search for the LGPL License document there.
 */
package supportedtypes;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Text;
import org.x2jb.bind.XML2Java;

import supportedtypes.ifaces.NonPrimitives;
import supportedtypes.ifaces.Primitives;
import supportedtypes.ifaces.SupportedTypes;

/**
 * Supported types sample
 *
 * @author <a href="mailto:richard_opalka@yahoo.com">Richard Opalka</a>
 */
public final class Main
{

    private Main()
    {
        super();
    }

    /**
     * Lookups specified resource on the classpath and returns parsed document instance
     * @param classpath resource to return
     */
    private static Document getDocument( final String resource ) throws Exception
    {
        Document retVal = null;

        try
        {
            final DocumentBuilderFactory builderFactory = DocumentBuilderFactory.newInstance();
            builderFactory.setIgnoringComments( true );
            final DocumentBuilder builder = builderFactory.newDocumentBuilder();
            retVal = builder.parse( Main.class.getResourceAsStream( resource ) );
        }
        catch ( ParserConfigurationException e )
        {
            e.printStackTrace( System.err );
            System.exit( 1 );
        }

        return retVal;
    }

    public static void main( final String[] args ) throws Exception
    {
        final Document parsedDocument = Main.getDocument( "/supportedtypes.xml" );
        final SupportedTypes supportedTypes = XML2Java.bind( parsedDocument, SupportedTypes.class );

        final Primitives primitives = supportedTypes.getPrimitives();
        System.out.println( "'boolean' attribute value is: " + primitives.getBoolean() );
        System.out.println( "'byte' attribute value is: " + primitives.getByte() );
        System.out.println( "'char' attribute value is: " + primitives.getChar() );
        System.out.println( "'short' attribute value is: " + primitives.getShort() );
        System.out.println( "'int' attribute value is: " + primitives.getInt() );
        System.out.println( "'long' attribute value is: " + primitives.getLong() );
        System.out.println( "'float' attribute value is: " + primitives.getFloat() );
        System.out.println( "'double' attribute value is: " + primitives.getDouble() );

        System.out.println();

        final NonPrimitives nonPrimitives = supportedTypes.getNonPrimitives();
        System.out.println( "'Boolean' element text value is: " + nonPrimitives.getBoolean() );
        System.out.println( "'Byte' element text value is: " + nonPrimitives.getByte() );
        System.out.println( "'Character' element text value is: " + nonPrimitives.getCharacter() );
        System.out.println( "'Short' element text value is: " + nonPrimitives.getShort() );
        System.out.println( "'Integer' element text value is: " + nonPrimitives.getInteger() );
        System.out.println( "'Long' element text value is: " + nonPrimitives.getLong() );
        System.out.println( "'Float' element text value is: " + nonPrimitives.getFloat() );
        System.out.println( "'Double' element text value is: " + nonPrimitives.getDouble() );
        System.out.println( "'String' element text value is: " + nonPrimitives.getString() );
        System.out.println( "'QName' element text value is: " + nonPrimitives.getQName() );
        System.out.println( "'BigInteger' element text value is: " + nonPrimitives.getBigInteger() );
        System.out.println( "'BigDecimal' element text value is: " + nonPrimitives.getBigDecimal() );
        System.out.println( "'Element' element text value is: " +
            ( ( Text ) nonPrimitives.getElement().getFirstChild() ).getData() );
    }
}
