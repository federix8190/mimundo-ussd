/*
 * XML 2 Java Binding (X2JB) - the excellent Java tool.
 * Copyright 2009, by Richard Opalka.
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not see the FSF site:
 * http://www.fsf.org/ and search for the LGPL License document there.
 */
package arrayssupport;

import arrayssupport.ifaces.Data;

import javax.xml.namespace.QName;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.x2jb.bind.XML2Java;

/**
 * Arrays support sample
 *
 * @author <a href="mailto:richard_opalka@yahoo.com">Richard Opalka</a>
 */
public final class Main
{

    private Main()
    {
        super();
    }

    /**
     * Lookups specified resource on the classpath and returns parsed document instance
     * @param classpath resource to return
     */
    private static Document getDocument( final String resource ) throws Exception
    {
        Document retVal = null;

        try
        {
            final DocumentBuilderFactory builderFactory = DocumentBuilderFactory.newInstance();
            builderFactory.setNamespaceAware( true );
            builderFactory.setIgnoringComments( true );
            final DocumentBuilder builder = builderFactory.newDocumentBuilder();
            retVal = builder.parse( Main.class.getResourceAsStream( resource ) );
        }
        catch ( ParserConfigurationException e )
        {
            e.printStackTrace( System.err );
            System.exit( 1 );
        }

        return retVal;
    }

    public static void main( final String[] args ) throws Exception
    {
        final Document parsedDocument = Main.getDocument( "/arrayssupport.xml" );
        final Data data = XML2Java.bind( parsedDocument, Data.class );
        final Data.Arrays arrays = data.getArrays();

        Main.printByteValues( arrays );
        Main.printCharacterValues( arrays );
        Main.printShortValues( arrays );
        Main.printIntegerValues( arrays );
        Main.printLongValues( arrays );
        Main.printFloatValues( arrays );
        Main.printDoubleValues( arrays );
        Main.printBigIntegerValues( arrays );
        Main.printBigDecimalValues( arrays );
        Main.printStringValues( arrays );
        Main.printQNameValues( arrays );
    }

    private static void printQNameValues( final Data.Arrays arrays )
    {
        // display QName array values
        final QName[] qnameValues = arrays.getQNameValues();
        for ( int i = 0; i < qnameValues.length; i++ )
        {
            System.out.println( "QName value on position " + i + " is " + qnameValues[ i ] );
        }
        System.out.println();
    }

    private static void printStringValues( final Data.Arrays arrays )
    {
        // display String array values
        final String[] stringValues = arrays.getStringValues();
        for ( int i = 0; i < stringValues.length; i++ )
        {
            System.out.println( "String value on position " + i + " is " + stringValues[ i ] );
        }
        System.out.println();
    }

    private static void printBigDecimalValues( final Data.Arrays arrays )
    {
        // display BigDecimal array values
        final java.math.BigDecimal[] bigDecimalValues = arrays.getBigDecimalValues();
        for ( int i = 0; i < bigDecimalValues.length; i++ )
        {
            System.out.println( "BigDecimal value on position " + i + " is " + bigDecimalValues[ i ] );
        }
        System.out.println();
    }

    private static void printBigIntegerValues( final Data.Arrays arrays )
    {
        // display BigInteger array values
        final java.math.BigInteger[] bigIntegerValues = arrays.getBigIntegerValues();
        for ( int i = 0; i < bigIntegerValues.length; i++ )
        {
            System.out.println( "BigInteger value on position " + i + " is " + bigIntegerValues[ i ] );
        }
        System.out.println();
    }

    private static void printDoubleValues( final Data.Arrays arrays )
    {
        // display double array values
        final double[] doubleValues = arrays.getDoubleValues();
        for ( int i = 0; i < doubleValues.length; i++ )
        {
            System.out.println( "double value on position " + i + " is " + doubleValues[ i ] );
        }
        System.out.println();
    }

    private static void printFloatValues( final Data.Arrays arrays )
    {
        // display float array values
        final float[] floatValues = arrays.getFloatValues();
        for ( int i = 0; i < floatValues.length; i++ )
        {
            System.out.println( "float value on position " + i + " is " + floatValues[ i ] );
        }
        System.out.println();
    }

    private static void printLongValues( final Data.Arrays arrays )
    {
        // display long array values
        final long[] longValues = arrays.getLongValues();
        for ( int i = 0; i < longValues.length; i++ )
        {
            System.out.println( "long value on position " + i + " is " + longValues[ i ] );
        }
        System.out.println();
    }

    private static void printIntegerValues( final Data.Arrays arrays )
    {
        // display int array values
        final int[] intValues = arrays.getIntValues();
        for ( int i = 0; i < intValues.length; i++ )
        {
            System.out.println( "int value on position " + i + " is " + intValues[ i ] );
        }
        System.out.println();
    }

    private static void printShortValues( final Data.Arrays arrays )
    {
        // display short array values
        final short[] shortValues = arrays.getShortValues();
        for ( int i = 0; i < shortValues.length; i++ )
        {
            System.out.println( "short value on position " + i + " is " + shortValues[ i ] );
        }
        System.out.println();
    }

    private static void printCharacterValues( final Data.Arrays arrays )
    {
        // display char array values
        final char[] charValues = arrays.getCharValues();
        for ( int i = 0; i < charValues.length; i++ )
        {
            System.out.println( "char value on position " + i + " is " + charValues[ i ] );
        }
        System.out.println();
    }

    private static void printByteValues( final Data.Arrays arrays )
    {
        // display byte array values
        final byte[] byteValues = arrays.getByteValues();
        for ( int i = 0; i < byteValues.length; i++ )
        {
            System.out.println( "byte value on position " + i + " is " + byteValues[ i ] );
        }
        System.out.println();
    }

}
