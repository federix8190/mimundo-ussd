/*
 * XML 2 Java Binding (X2JB) - the excellent Java tool.
 * Copyright 2009, by Richard Opalka.
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not see the FSF site:
 * http://www.fsf.org/ and search for the LGPL License document there.
 */
package helloworld;

import helloworld.ifaces.HelloWorld;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.x2jb.bind.XML2Java;

/**
 * Hello world sample
 *
 * @author <a href="mailto:richard_opalka@yahoo.com">Richard Opalka</a>
 */
public final class Main
{

    private Main()
    {
        super();
    }

    /**
     * Lookups specified resource on the classpath and returns parsed document instance
     * @param classpath resource to return
     */
    private static Document getDocument( final String resource ) throws Exception
    {
        Document retVal = null;

        try
        {
            final DocumentBuilderFactory builderFactory = DocumentBuilderFactory.newInstance();
            builderFactory.setIgnoringComments( true );
            final DocumentBuilder builder = builderFactory.newDocumentBuilder();
            retVal = builder.parse( Main.class.getResourceAsStream( resource ) );
        }
        catch ( ParserConfigurationException e )
        {
            e.printStackTrace( System.err );
            System.exit( 1 );
        }

        return retVal;
    }

    public static void main( final String[] args ) throws Exception
    {
        final Document parsedDocument = Main.getDocument( "/helloworld.xml" );
        final HelloWorld helloWorld = XML2Java.bind( parsedDocument, HelloWorld.class );

        System.out.println( helloWorld.getMessageFromElement() );
        System.out.println( helloWorld.getMessageFromAttribute() );
    }

}
