/*
 * XML 2 Java Binding (X2JB) - the excellent Java tool.
 * Copyright 2009, by Richard Opalka.
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not see the FSF site:
 * http://www.fsf.org/ and search for the LGPL License document there.
 */
package webapp;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.Document;
import org.x2jb.bind.XML2Java;

import webapp.ifaces.Description;
import webapp.ifaces.EnvEntry;
import webapp.ifaces.Filter;
import webapp.ifaces.FilterMapping;
import webapp.ifaces.Listener;
import webapp.ifaces.Parameter;
import webapp.ifaces.Servlet;
import webapp.ifaces.ServletMapping;
import webapp.ifaces.SessionConfig;
import webapp.ifaces.WebApp;
import webapp.ifaces.WelcomeFileList;

/**
 * Web app sample
 * @author <a href="mailto:richard_opalka@yahoo.com">Richard Opalka</a>
 */
public final class Main
{

    private static final int PADDING_SIZE = 4;

    private Main()
    {
        super();
    }

    /**
     * Lookups specified resource on the classpath and returns parsed document instance
     * @param classpath resource to return
     */
    private static Document getDocument( final String resource ) throws Exception
    {
        Document retVal = null;

        try
        {
            final DocumentBuilderFactory builderFactory = DocumentBuilderFactory.newInstance();
            builderFactory.setIgnoringComments( true );
            final DocumentBuilder builder = builderFactory.newDocumentBuilder();
            retVal = builder.parse( Main.class.getResourceAsStream( resource ) );
        }
        catch ( ParserConfigurationException e )
        {
            e.printStackTrace( System.err );
            System.exit( 1 );
        }

        return retVal;
    }

    public static void main( final String[] args ) throws Exception
    {
        final Document parsedDocument = Main.getDocument( "/web.xml" );
        final WebApp webApp = XML2Java.bind( parsedDocument, WebApp.class );

        System.out.println();
        System.out.println( "Web application configuration: " );
        System.out.println();
        Main.printDescription( webApp.getDescription(), 0 );
        System.out.println();
        Main.printFilters( webApp.getFilters(), 0 );
        Main.printFilterMappings( webApp.getFilterMappings(), 0 );  
        Main.printListeners( webApp.getListeners(), 0 );
        Main.printServlets( webApp.getServlets(), 0 );
        Main.printServletMappings( webApp.getServletMappings(), 0 );
        Main.printEnvEntries( webApp.getEnvEntries(), 0 );
        Main.printSessionConfig( webApp.getSessionConfig(), 0 );
        Main.printWelcomeFileList( webApp.getWelcomeFileList(), 0 );
    }

    private static void printWelcomeFileList( final WelcomeFileList list, final int level )
    {
        if ( list != null )
        {
            final String[] welcomeFiles = list.getFiles();
            if ( welcomeFiles.length != 0 )
            {
                Main.printPadding( level );
                System.out.println( "Welcome file list: " );
                System.out.println();
                for ( int i = 0; i < welcomeFiles.length; i++ )
                {
                    Main.printPadding( level + 1 );
                    System.out.println( "Welcome file: " + welcomeFiles[ i ] );
                }
                System.out.println();
            }
        }
    }

    private static void printSessionConfig( final SessionConfig config, final int level )
    {
        if ( config != null )
        {
            Main.printPadding( level );
            System.out.println( "Session timeout: " + config.getSessionTimeout() );
            System.out.println();
        }
    }

    private static void printEnvEntries( final EnvEntry[] entries, final int level )
    {
        if ( entries.length != 0 )
        {
            Main.printPadding( level );
            System.out.println( "Environment Entries: " );
            System.out.println();
            for ( int i = 0; i < entries.length; i++ )
            {
                final EnvEntry e = entries[ i ];
                Main.printDescription( e.getDescription(), level + 1 );
                Main.printPadding( level + 1 );
                System.out.println( "Entry name: " + e.getName() );
                Main.printPadding( level + 1 );
                System.out.println( "Entry type: " + e.getType() );
                if ( e.getValue() != null )
                {
                    Main.printPadding( level + 1 );
                    System.out.println( "Entry value: " + e.getValue() );
                }
                System.out.println();
            }
        }
    }

    private static void printServletMappings( final ServletMapping[] servletMappings, final int level )
    {
        if ( servletMappings.length != 0 )
        {
            Main.printPadding( level );
            System.out.println( "Servlet mappings: " );
            System.out.println();
            for ( int i = 0; i < servletMappings.length; i++ )
            {
                final ServletMapping s = servletMappings[ i ];
                Main.printPadding( level + 1 );
                System.out.println( "Servlet name: " + s.getServletName() );
                Main.printPadding( level + 1 );
                System.out.println( "URL pattern: " + s.getUrlPattern() );
                System.out.println();
            }
        }
    }

    private static void printListeners( final Listener[] listeners, final int level )
    {
        if ( listeners.length != 0 )
        {
            Main.printPadding( level );
            System.out.println( "Listeners: " );
            System.out.println();
            for ( int i = 0; i < listeners.length; i++ )
            {
                final Listener l = listeners[ i ];
                Main.printPadding( level + 1 );
                System.out.println( "Listener class: " + l.getListenerClass() );
                System.out.println();
            }
        }
    }

    private static void printPadding( final int level )
    {
        for ( int i = 0; i < level * Main.PADDING_SIZE; i++ )
        {
            System.out.print( ' ' );
        }
    }

    private static void printDescription( final Description desc, final int level )
    {
        if ( desc.getDescription() != null )
        {
            Main.printPadding( level );
            System.out.println( "Description: " + desc.getDescription() );
        }
        if ( desc.getDisplayName() != null )
        {
            Main.printPadding( level );
            System.out.println( "Display name: " + desc.getDisplayName() );
        }
        if ( desc.getIcon() != null )
        {
            Main.printPadding( level );
            System.out.println( "Icon: " + desc.getIcon() );
        }
    }

    private static void printFilters( final Filter[] filters, final int level )
    {
        if ( filters.length != 0 )
        {
            Main.printPadding( level );
            System.out.println( "Filters: " );
            System.out.println();
            for ( int i = 0; i < filters.length; i++ )
            {
                final Filter f = filters[ i ];
                Main.printDescription( f.getDescription(), level + 1 );
                Main.printPadding( level + 1 );
                System.out.println( "Filter name: " + f.getName() );
                Main.printPadding( level + 1 );
                System.out.println( "Filter class: " + f.getClassName() );
                Main.printParams( f.getInitParams(), level + 2 );
                System.out.println();
            }
        }
    }

    private static void printServlets( final Servlet[] servlets, final int level )
    {
        if ( servlets.length != 0 )
        {
            Main.printPadding( level );
            System.out.println( "Servlets: " );
            System.out.println();
            for ( int i = 0; i < servlets.length; i++ )
            {
                final Servlet s = servlets[ i ];
                Main.printPadding( level + 1 );
                System.out.println( "Servlet name: " + s.getName() );
                Main.printPadding( level + 1 );
                if ( s.getClassName() != null )
                {
                    System.out.println( "Servlet class: " + s.getClassName() );
                }
                else
                {
                    System.out.println( "Servlet JSP file: " + s.getJspFile() );
                }
                if ( s.getLoadOnStartup() != 0 )
                {
                    Main.printPadding( level + 1 );
                    System.out.println( "Load on startup: " + s.getLoadOnStartup() );
                }
                Main.printParams( s.getInitParams(), level + 2 );
                System.out.println();
            }
        }
    }

    private static void printFilterMappings( final FilterMapping[] filterMappings, final int level )
    {
        if ( filterMappings.length != 0 )
        {
            Main.printPadding( level );
            System.out.println( "Filter mappings: " );
            System.out.println();
            for ( int i = 0; i < filterMappings.length; i++ )
            {
                final FilterMapping f = filterMappings[ i ];
                Main.printPadding( level + 1 );
                System.out.println( "Filter name: " + f.getFilterName() );
                Main.printPadding( level + 1 );
                if ( f.getServletName() != null )
                {
                    System.out.println( "Applies to servlet: " + f.getServletName() );
                }
                else
                {
                    System.out.println( "Applies to URL pattern: " + f.getURLPattern() );
                }
                final Dispatcher[] dispatchers = f.getDispatchers();
                if ( dispatchers.length != 0 )
                {
                    Main.printPadding( level + 1 );
                    System.out.print( "Dispatchers: " );
                    for ( int j = 0; j < dispatchers.length; j++ )
                    {
                        System.out.print( dispatchers[ j ] + " " );
                    }
                    System.out.println();
                }
                System.out.println();
            }
        }
    }

    private static void printParams( final Parameter[] params, final int level )
    {
        for ( int i = 0; i < params.length; i++ )
        {
            System.out.println();
            final Parameter p = params[ i ];
            if ( p.getDescription() != null )
            {
                Main.printPadding( level );
                System.out.println( "Parameter description: " + p.getDescription() );
            }
            Main.printPadding( level );
            System.out.println( "Param name: " + p.getName() );
            Main.printPadding( level );
            System.out.println( "Param value: " + p.getValue() );
        }
    }

}
