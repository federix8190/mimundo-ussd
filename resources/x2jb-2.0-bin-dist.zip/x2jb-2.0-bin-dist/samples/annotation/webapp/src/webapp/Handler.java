/*
 * XML 2 Java Binding (X2JB) - the excellent Java tool.
 * Copyright 2009, by Richard Opalka.
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not see the FSF site:
 * http://www.fsf.org/ and search for the LGPL License document there.
 */ 
package webapp;

import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.Text;
import org.x2jb.bind.BindingException;
import org.x2jb.bind.spi.handler.ElementHandler;

/**
 * Web app sample
 *
 * @author <a href="mailto:richard_opalka@yahoo.com">Richard Opalka</a>
 */
public final class Handler implements ElementHandler
{

    public Handler()
    {
        super();
    }

    public Object bind( final Element element, final Class< ? > clazz )
    {
        if ( clazz.equals( Dispatcher.class ) )
        {
            return Dispatcher.valueOf( Handler.getTextContent( element ) );
        }

        throw new BindingException( "Handler doesn't support '" + clazz.getName() + "' class" );
    }

    private static String getTextContent( final Element e )
    {
        final Node childNode = e.getFirstChild();

        if ( ( childNode == null ) || ( !( childNode instanceof Text ) ) )
        {
            throw new BindingException( "Text node expected but not found" );
        }
        else
        {
            return ( ( Text ) childNode ).getData();
        }
    }

    public Object getDefault( final String defaultValue, final Class< ? > clazz )
    {
        return null;
    }

}
