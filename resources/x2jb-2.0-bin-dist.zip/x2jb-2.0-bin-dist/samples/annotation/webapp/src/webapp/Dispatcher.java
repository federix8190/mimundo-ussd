/*
 * XML 2 Java Binding (X2JB) - the excellent Java tool.
 * Copyright 2009, by Richard Opalka.
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not see the FSF site:
 * http://www.fsf.org/ and search for the LGPL License document there.
 */
package webapp;

/**
 * Web app sample
 * @author <a href="mailto:richard_opalka@yahoo.com">Richard Opalka</a>
 */
public final class Dispatcher
{

    /** Dispatcher type in web.xml is <code>FORWARD</code> */
    public static final Dispatcher FORWARD = new Dispatcher( "FORWARD" );
    /** Dispatcher type in web.xml is <code>INCLUDE</code> */
    public static final Dispatcher INCLUDE = new Dispatcher( "INCLUDE" );
    /** Dispatcher type in web.xml is <code>REQUEST</code> */
    public static final Dispatcher REQUEST = new Dispatcher( "REQUEST" );
    /** Dispatcher type in web.xml is <code>ERROR</code> */
    public static final Dispatcher ERROR = new Dispatcher( "ERROR" );

    private final String type;

    /**
     * Forbidden constructor
     * @param type dispatcher type
     */
    private Dispatcher( final String t )
    {
        super();
        this.type = t;
    }

    /**
     * Factory method which converts passed <code>String</code> to <code>DispatcherType</code>
     * @param s to be converted
     * @return <code>DispatcherType</code> instance or null if no match was found
     */
    public static Dispatcher valueOf( final String s )
    {
        if ( s != null )
        {
            if ( Dispatcher.FORWARD.toString().equals( s ) )
            {
                return Dispatcher.FORWARD;
            }
            if ( Dispatcher.INCLUDE.toString().equals( s ) )
            {
                return Dispatcher.INCLUDE;
            }
            if ( Dispatcher.REQUEST.toString().equals( s ) )
            {
                return Dispatcher.REQUEST;
            }
            if ( Dispatcher.ERROR.toString().equals( s ) )
            {
                return Dispatcher.ERROR;
            }
        }

        return null;
    }

    public String toString()
    {
        return this.type;
    }

}
