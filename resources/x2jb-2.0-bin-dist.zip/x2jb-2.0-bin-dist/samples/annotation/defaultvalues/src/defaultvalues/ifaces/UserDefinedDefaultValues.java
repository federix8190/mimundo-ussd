/*
 * XML 2 Java Binding (X2JB) - the excellent Java tool.
 * Copyright 2009, by Richard Opalka.
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not see the FSF site:
 * http://www.fsf.org/ and search for the LGPL License document there.
 */
package defaultvalues.ifaces;

import org.x2jb.bind.Binding;

/**
 * This interface was generated, do not modify it.
 *
 * @author <a href="mailto:richard_opalka@yahoo.com">Richard Opalka</a>
 */
public interface UserDefinedDefaultValues
{

    @Binding
    (
        nodeName = "not_existing_element",
        isNodeMandatory = false,
        defaultValue = "yes"
    )
    boolean getBooleanPrimitive( );

    @Binding
    (
        nodeName = "not_existing_element",
        isNodeMandatory = false,
        defaultValue = "2"
    )
    byte getBytePrimitive( );

    @Binding
    (
        nodeName = "not_existing_element",
        isNodeMandatory = false,
        defaultValue = "3"
    )
    char getCharPrimitive( );

    @Binding
    (
        nodeName = "not_existing_element",
        isNodeMandatory = false,
        defaultValue = "5"
    )
    short getShortPrimitive( );

    @Binding
    (
        nodeName = "not_existing_element",
        isNodeMandatory = false,
        defaultValue = "7"
    )
    int getIntPrimitive( );

    @Binding
    (
        nodeName = "not_existing_element",
        isNodeMandatory = false,
        defaultValue = "11"
    )
    long getLongPrimitive( );

    @Binding
    (
        nodeName = "not_existing_element",
        isNodeMandatory = false,
        defaultValue = "13."
    )
    float getFloatPrimitive( );

    @Binding
    (
        nodeName = "not_existing_element",
        isNodeMandatory = false,
        defaultValue = "17."
    )
    double getDoublePrimitive( );

    @Binding
    (
        nodeName = "not_existing_element",
        isNodeMandatory = false,
        defaultValue = "1"
    )
    Boolean getBoolean( );

    @Binding
    (
        nodeName = "not_existing_element",
        isNodeMandatory = false,
        defaultValue = "2"
    )
    Byte getByte( );

    @Binding
    (
        nodeName = "not_existing_element",
        isNodeMandatory = false,
        defaultValue = "3"
    )
    Character getCharacter( );

    @Binding
    (
        nodeName = "not_existing_element",
        isNodeMandatory = false,
        defaultValue = "5"
    )
    Short getShort( );

    @Binding
    (
        nodeName = "not_existing_element",
        isNodeMandatory = false,
        defaultValue = "7"
    )
    Integer getInteger( );

    @Binding
    (
        nodeName = "not_existing_element",
        isNodeMandatory = false,
        defaultValue = "11"
    )
    Long getLong( );

    @Binding
    (
        nodeName = "not_existing_element",
        isNodeMandatory = false,
        defaultValue = "13."
    )
    Float getFloat( );

    @Binding
    (
        nodeName = "not_existing_element",
        isNodeMandatory = false,
        defaultValue = "17."
    )
    Double getDouble( );

    @Binding
    (
        nodeName = "not_existing_element",
        isNodeMandatory = false,
        defaultValue = "some string"
    )
    String getString( );

    @Binding
    (
        nodeName = "not_existing_element",
        isNodeMandatory = false,
        defaultValue = "{http://mycompany/}myDevision"
    )
    javax.xml.namespace.QName getQName( );

    @Binding
    (
        nodeName = "not_existing_element",
        isNodeMandatory = false,
        defaultValue = "1"
    )
    java.math.BigInteger getBigInteger( );

    @Binding
    (
        nodeName = "not_existing_element",
        isNodeMandatory = false,
        defaultValue = "1"
    )
    java.math.BigDecimal getBigDecimal( );

    @Binding
    (
        nodeName = "not_existing_element",
        isNodeMandatory = false,
        defaultValue = "NONSENSE"
    )
    org.w3c.dom.Element getElement( );

    @Binding
    (
        nodeName = "not_existing_element",
        isNodeMandatory = false,
        isNodeUnique = false,
        defaultValue = "NONSENSE"
    )
    DummyIface getInterface( );

    @Binding
    (
        nodeName = "not_existing_element",
        isNodeMandatory = false,
        isNodeUnique = false,
        defaultValue = "NONSENSE"
    )
    Boolean[] getBooleanArray( );

}
