/*
 * XML 2 Java Binding (X2JB) - the excellent Java tool.
 * Copyright 2009, by Richard Opalka.
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not see the FSF site:
 * http://www.fsf.org/ and search for the LGPL License document there.
 */
package defaultvalues.ifaces;

import org.x2jb.bind.Binding;

/**
 * This interface was generated, do not modify it.
 *
 * @author <a href="mailto:richard_opalka@yahoo.com">Richard Opalka</a>
 */
public interface DefaultValues
{

    @Binding
    (
        nodeName = "not_existing_element",
        isNodeMandatory = false
    )
    boolean getBooleanPrimitive( );

    @Binding
    (
        nodeName = "not_existing_element",
        isNodeMandatory = false
    )
    byte getBytePrimitive( );

    @Binding
    (
        nodeName = "not_existing_element",
        isNodeMandatory = false
    )
    char getCharPrimitive( );

    @Binding
    (
        nodeName = "not_existing_element",
        isNodeMandatory = false
    )
    short getShortPrimitive( );

    @Binding
    (
        nodeName = "not_existing_element",
        isNodeMandatory = false
    )
    int getIntPrimitive( );

    @Binding
    (
        nodeName = "not_existing_element",
        isNodeMandatory = false
    )
    long getLongPrimitive( );

    @Binding
    (
        nodeName = "not_existing_element",
        isNodeMandatory = false
    )
    float getFloatPrimitive( );

    @Binding
    (
        nodeName = "not_existing_element",
        isNodeMandatory = false
    )
    double getDoublePrimitive( );

    @Binding
    (
        nodeName = "not_existing_element",
        isNodeMandatory = false
    )
    Boolean getBoolean( );

    @Binding
    (
        nodeName = "not_existing_element",
        isNodeMandatory = false
    )
    Byte getByte( );

    @Binding
    (
        nodeName = "not_existing_element",
        isNodeMandatory = false
    )
    Character getCharacter( );

    @Binding
    (
        nodeName = "not_existing_element",
        isNodeMandatory = false
    )
    Short getShort( );

    @Binding
    (
        nodeName = "not_existing_element",
        isNodeMandatory = false
    )
    Integer getInteger( );

    @Binding
    (
        nodeName = "not_existing_element",
        isNodeMandatory = false
    )
    Long getLong( );

    @Binding
    (
        nodeName = "not_existing_element",
        isNodeMandatory = false
    )
    Float getFloat( );

    @Binding
    (
        nodeName = "not_existing_element",
        isNodeMandatory = false
    )
    Double getDouble( );

    @Binding
    (
        nodeName = "not_existing_element",
        isNodeMandatory = false
    )
    String getString( );

    @Binding
    (
        nodeName = "not_existing_element",
        isNodeMandatory = false
    )
    javax.xml.namespace.QName getQName( );

    @Binding
    (
        nodeName = "not_existing_element",
        isNodeMandatory = false
    )
    java.math.BigInteger getBigInteger( );

    @Binding
    (
        nodeName = "not_existing_element",
        isNodeMandatory = false
    )
    java.math.BigDecimal getBigDecimal( );

    @Binding
    (
        nodeName = "not_existing_element",
        isNodeMandatory = false
    )
    org.w3c.dom.Element getElement( );

    @Binding
    (
        nodeName = "not_existing_element",
        isNodeMandatory = false,
        isNodeUnique = false
    )
    DummyIface getInterface( );

    @Binding
    (
        nodeName = "not_existing_element",
        isNodeMandatory = false,
        isNodeUnique = false
    )
    Boolean[] getBooleanArray( );

}
