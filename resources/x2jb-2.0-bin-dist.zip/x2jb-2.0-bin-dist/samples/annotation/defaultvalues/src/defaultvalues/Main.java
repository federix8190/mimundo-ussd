/*
 * XML 2 Java Binding (X2JB) - the excellent Java tool.
 * Copyright 2009, by Richard Opalka.
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not see the FSF site:
 * http://www.fsf.org/ and search for the LGPL License document there.
 */
package defaultvalues;

import defaultvalues.ifaces.DefaultValues;
import defaultvalues.ifaces.UserDefinedDefaultValues;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.x2jb.bind.XML2Java;

/**
 * Default values sample
 *
 * @author <a href="mailto:richard_opalka@yahoo.com">Richard Opalka</a>
 */
public final class Main
{

    private Main()
    {
        super();
    }

    /**
     * Lookups specified resource on the classpath and returns parsed document instance
     * @param classpath resource to return
     */
    private static Document getDocument( final String resource ) throws Exception
    {
        Document retVal = null;
        try
        {
            final DocumentBuilderFactory builderFactory = DocumentBuilderFactory.newInstance();
            builderFactory.setIgnoringComments( true );
            final DocumentBuilder builder = builderFactory.newDocumentBuilder();
            retVal = builder.parse( Main.class.getResourceAsStream( resource ) );
        }
        catch ( ParserConfigurationException e )
        {
            e.printStackTrace( System.err );
            System.exit( 1 );
        }
        return retVal;
    }

    public static void main( final String[] args ) throws Exception
    {
        final Document parsedDocument = Main.getDocument( "/defaultvalues.xml" );

        final DefaultValues defaultValues = 
            XML2Java.bind( parsedDocument, DefaultValues.class ); 
        Main.printDefaultValues( defaultValues );

        final UserDefinedDefaultValues userDefinedDefaultValues = 
            XML2Java.bind( parsedDocument, UserDefinedDefaultValues.class );
        Main.printUserDefinedDefaultValues( userDefinedDefaultValues );

    }

    private static void printDefaultValues( final DefaultValues defaultValues )
    {
        // X2JB primitives default values are identical to those specified in the Java Language Specification
        System.out.println( "Default boolean value is: " +
            defaultValues.getBooleanPrimitive() );
        System.out.println( "Default byte value is: " +
            defaultValues.getBytePrimitive() );
        System.out.println( "Default char value is: " +
            defaultValues.getCharPrimitive() );
        System.out.println( "Default short value is: " +
            defaultValues.getShortPrimitive() );
        System.out.println( "Default int value is: " +
            defaultValues.getIntPrimitive() );
        System.out.println( "Default long value is: " +
            defaultValues.getLongPrimitive() );
        System.out.println( "Default float value is: " +
            defaultValues.getFloatPrimitive() );
        System.out.println( "Default double value is: " +
            defaultValues.getDoublePrimitive() );
        // Supported Java nonprimitives are always mapped to null. Exception to this rule are arrays
        System.out.println( "Default Boolean value is: " +
            defaultValues.getBoolean() );
        System.out.println( "Default Byte value is: " +
            defaultValues.getByte() );
        System.out.println( "Default Character value is: " +
            defaultValues.getCharacter() );
        System.out.println( "Default Short value is: " +
            defaultValues.getShort() );
        System.out.println( "Default Integer value is: " +
            defaultValues.getInteger() );
        System.out.println( "Default Long value is: " +
            defaultValues.getLong() );
        System.out.println( "Default Float value is: " +
            defaultValues.getFloat() );
        System.out.println( "Default Double value is: " +
            defaultValues.getDouble() );
        System.out.println( "Default String value is: " +
            defaultValues.getString() );
        System.out.println( "Default QName value is: " +
            defaultValues.getQName() );
        System.out.println( "Default BigInteger value is: " +
            defaultValues.getBigInteger() );
        System.out.println( "Default BigDecimal value is: " +
            defaultValues.getBigDecimal() );
        System.out.println( "Default Element value is: " +
            defaultValues.getElement() );
        System.out.println( "Default Interface value is: " +
            defaultValues.getInterface() );
        // Array is always mapped to zero length array regardless the array component type
        System.out.println( "Default Boolean[] value is: " +
            defaultValues.getBooleanArray().length + " length array." );
    }

    private static void printUserDefinedDefaultValues( final UserDefinedDefaultValues defaultValues )
    {
        // displaying user defined default values using binding defaultValue attribute
        System.out.println( "User defined default boolean value is: " +
            defaultValues.getBooleanPrimitive() );
        System.out.println( "User defined default byte value is: " +
            defaultValues.getBytePrimitive() );
        System.out.println( "User defined default char value is: " +
            defaultValues.getCharPrimitive() );
        System.out.println( "User defined default short value is: " +
            defaultValues.getShortPrimitive() );
        System.out.println( "User defined default int value is: " +
            defaultValues.getIntPrimitive() );
        System.out.println( "User defined default long value is: " +
            defaultValues.getLongPrimitive() );
        System.out.println( "User defined default float value is: " +
            defaultValues.getFloatPrimitive() );
        System.out.println( "User defined default double value is: " +
            defaultValues.getDoublePrimitive() );
        // Supported Java nonprimitives are always mapped to null. User however can specify default value for them.
        System.out.println( "User defined default Boolean value is: " +
            defaultValues.getBoolean() );
        System.out.println( "User defined default Byte value is: " +
            defaultValues.getByte() );
        System.out.println( "User defined default Character value is: " +
            defaultValues.getCharacter() );
        System.out.println( "User defined default Short value is: " +
            defaultValues.getShort() );
        System.out.println( "User defined default Integer value is: " +
            defaultValues.getInteger() );
        System.out.println( "User defined default Long value is: " +
            defaultValues.getLong() );
        System.out.println( "User defined default Float value is: " +
            defaultValues.getFloat() );
        System.out.println( "User defined default Double value is: " +
            defaultValues.getDouble() );
        System.out.println( "User defined default String value is: " +
            defaultValues.getString() );
        System.out.println( "User defined default QName value is: " +
            defaultValues.getQName() );
        System.out.println( "User defined default BigInteger value is: " +
            defaultValues.getBigInteger() );
        System.out.println( "User defined default BigDecimal value is: " +
            defaultValues.getBigDecimal() );
        System.out.println( "User defined default Element value is: " +
            defaultValues.getElement() );
        System.out.println( "User defined default Interface value is: " +
            defaultValues.getInterface() );
        // Array is always mapped to zero length array regardless the array component type.
        System.out.println( "User defined default Boolean[] value is: " +
            defaultValues.getBooleanArray().length + " length array." );
    }

}
