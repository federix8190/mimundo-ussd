/*
 * XML 2 Java Binding (X2JB) - the excellent Java tool.
 * Copyright 2009, by Richard Opalka.
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not see the FSF site:
 * http://www.fsf.org/ and search for the LGPL License document there.
 */
package mutability;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Arrays;

import javax.xml.namespace.QName;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import mutability.ifaces.MutableConfig;
import mutability.ifaces.UnchangeableConfig;

import org.w3c.dom.Document;
import org.x2jb.bind.XML2Java;

/**
 * Default values sample
 *
 * @author <a href="mailto:richard_opalka@yahoo.com">Richard Opalka</a>
 */
public final class Main
{

    private Main()
    {
        super();
    }

    /**
     * Lookups specified resource on the classpath and returns parsed document instance
     * @param classpath resource to return
     */
    private static Document getDocument( final String resource ) throws Exception
    {
        Document retVal = null;
        try
        {
            final DocumentBuilderFactory builderFactory = DocumentBuilderFactory.newInstance();
            builderFactory.setIgnoringComments( true );
            final DocumentBuilder builder = builderFactory.newDocumentBuilder();
            retVal = builder.parse( Main.class.getResourceAsStream( resource ) );
        }
        catch ( ParserConfigurationException e )
        {
            e.printStackTrace( System.err );
            System.exit( 1 );
        }
        return retVal;
    }

    public static void main( final String[] args ) throws Exception
    {
        final Document parsedDocument = Main.getDocument( "/config.xml" );

        final MutableConfig config = 
            XML2Java.bind( parsedDocument, MutableConfig.class );
        
        System.out.println();
        System.out.println( "Original config values:" );
        Main.printValues( config );
        Main.changeValues( config );
        System.out.println();
        System.out.println( "Modified config values:" );
        Main.printValues( config );
    }

    private static void printValues( final UnchangeableConfig config )
    {
        // X2JB default bindings are created from method names
        System.out.println( "Primitive boolean value is: " +
            config.getBooleanPrimitive() );
        System.out.println( "Primitive byte value is: " +
            config.getBytePrimitive() );
        System.out.println( "Primitive char value is: " +
            config.getCharPrimitive() );
        System.out.println( "Primitive short value is: " +
            config.getShortPrimitive() );
        System.out.println( "Primitive int value is: " +
            config.getIntPrimitive() );
        System.out.println( "Primitive long value is: " +
            config.getLongPrimitive() );
        System.out.println( "Primitive float value is: " +
            config.getFloatPrimitive() );
        System.out.println( "Primitive double value is: " +
            config.getDoublePrimitive() );
        System.out.println( "Boolean value is: " +
            config.getBoolean() );
        System.out.println( "Byte value is: " +
            config.getByte() );
        System.out.println( "Character value is: " +
            config.getCharacter() );
        System.out.println( "Short value is: " +
            config.getShort() );
        System.out.println( "Integer value is: " +
            config.getInteger() );
        System.out.println( "Long value is: " +
            config.getLong() );
        System.out.println( "Float value is: " +
            config.getFloat() );
        System.out.println( "Double value is: " +
            config.getDouble() );
        System.out.println( "String value is: " +
            config.getString() );
        System.out.println( "QName value is: " +
            config.getQName() );
        System.out.println( "BigInteger value is: " +
            config.getBigInteger() );
        System.out.println( "BigDecimal value is: " +
            config.getBigDecimal() );
        System.out.println( "Boolean array values are: " +
            Arrays.asList( config.getBooleanArray() ) );
    }

    private static void changeValues( final MutableConfig config )
    {
        // changing configuration values
        config.setBooleanPrimitive( true );
        config.setBytePrimitive( ( byte ) 2 );
        config.setCharPrimitive( 'n' );
        config.setShortPrimitive( ( short ) 4 );
        config.setIntPrimitive( 6 );
        config.setLongPrimitive( 8 );
        config.setFloatPrimitive( ( float ) 10. );
        config.setDoublePrimitive( 12. );
        config.setBoolean( Boolean.TRUE );
        config.setByte( Byte.valueOf( ( byte ) 14 ) );
        config.setCharacter( Character.valueOf( 'N' ) );
        config.setShort( Short.valueOf( ( short ) 16 ) );
        config.setInteger( Integer.valueOf( 18 ) );
        config.setLong( Long.valueOf( 20 ) );
        config.setFloat( Float.valueOf( ( float ) 22. ) );
        config.setDouble( Double.valueOf( 24. ) );
        config.setString( "modified hello" );
        config.setQName( QName.valueOf( "{http://mycompany}/modified_department" ) );
        config.setBigInteger( BigInteger.valueOf( 26 ) );
        config.setBigDecimal( BigDecimal.valueOf( 28. ) );
        // X2JB runtime creates array copies in get methods returning arrays
        final Boolean[] booleanArray = config.getBooleanArray();
        for ( int i = 0; i < booleanArray.length; i++ )
        {
            booleanArray[ i ] = Boolean.TRUE;
        }
        // setup modified array copy as new value
        config.setBooleanArray( booleanArray );
    }

}
