/*
 * XML 2 Java Binding (X2JB) - the excellent Java tool.
 * Copyright 2009, by Richard Opalka.
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not see the FSF site:
 * http://www.fsf.org/ and search for the LGPL License document there.
 */
package customhandler;

import customhandler.ifaces.TimeAndLocation;

import org.w3c.dom.Attr;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.Text;

import org.x2jb.bind.BindingException;
import org.x2jb.bind.spi.handler.AttributeHandler;
import org.x2jb.bind.spi.handler.ElementHandler;

/**
 * Custom handler sample
 *
 * @author <a href="mailto:richard_opalka@yahoo.com">Richard Opalka</a>
 */
public final class Handler implements ElementHandler, AttributeHandler
{

    private static final String DATE = "date";
    private static final String START_TIME = "start-time";
    private static final String END_TIME = "end-time";
    private static final String ROOM = "room";

    public Handler()
    {
        super();
    }

    public Object bind( final Element e, final Class< ? > c )
    {
        if ( c.equals( TimeAndLocation.class ) )
        {
            final String date = Handler.getTextContent( e.getElementsByTagName( Handler.DATE ).item( 0 ) );
            final String startTime = Handler.getTextContent( e.getElementsByTagName( Handler.START_TIME ).item( 0 ) );
            final String endTime = Handler.getTextContent( e.getElementsByTagName( Handler.END_TIME ).item( 0 ) );
            final String room = Handler.getTextContent( e.getElementsByTagName( Handler.ROOM ).item( 0 ) );

            // preparing return value for TimeAndLocation.getValue() method
            final StringBuffer sb = new StringBuffer().append( " is on " ).append( date )
                .append( ". It starts at " ).append( startTime ).append( " in " ).append( room )
                    .append( " room and ends at " ).append( endTime ).append( "." );
            // Note that TimeAndLocation interface contains no binding definitions.
            // It is not necessary because the interface is created in our custom handler.
            return new TimeAndLocation()
            {
                public String getValue()
                {
                    return sb.toString();
                }
            };
        }

        throw new BindingException( "Handler doesn't support '" + c.getName() + "' class" );
    }

    public Object bind( final Attr a, final Class< ? > c )
    {
        if ( c.equals( String.class ) )
        {
            return "My " + a.getValue();
        }

        throw new BindingException( "Handler doesn't support '" + c.getName() + "' class" );
    }

    public Object getDefault( final String defaultValue, final Class< ? > c )
    {
        return null;
    }

    private static String getTextContent( final Node e )
    {
        final Node childNode = e.getFirstChild();

        if ( ( childNode == null ) || ( !( childNode instanceof Text ) ) )
        {
            return null;
        }
        else
        {
            return ( ( Text ) childNode ).getData();
        }
    }

}
