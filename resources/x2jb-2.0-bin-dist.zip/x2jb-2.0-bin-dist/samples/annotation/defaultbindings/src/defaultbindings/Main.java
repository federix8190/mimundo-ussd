/*
 * XML 2 Java Binding (X2JB) - the excellent Java tool.
 * Copyright 2009, by Richard Opalka.
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not see the FSF site:
 * http://www.fsf.org/ and search for the LGPL License document there.
 */
package defaultbindings;

import defaultbindings.ifaces.DefaultBindings;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.x2jb.bind.XML2Java;

/**
 * Default values sample
 *
 * @author <a href="mailto:richard_opalka@yahoo.com">Richard Opalka</a>
 */
public final class Main
{

    private Main()
    {
        super();
    }

    /**
     * Lookups specified resource on the classpath and returns parsed document instance
     * @param classpath resource to return
     */
    private static Document getDocument( final String resource ) throws Exception
    {
        Document retVal = null;
        try
        {
            final DocumentBuilderFactory builderFactory = DocumentBuilderFactory.newInstance();
            builderFactory.setIgnoringComments( true );
            final DocumentBuilder builder = builderFactory.newDocumentBuilder();
            retVal = builder.parse( Main.class.getResourceAsStream( resource ) );
        }
        catch ( ParserConfigurationException e )
        {
            e.printStackTrace( System.err );
            System.exit( 1 );
        }
        return retVal;
    }

    public static void main( final String[] args ) throws Exception
    {
        final Document parsedDocument = Main.getDocument( "/defaultbindings.xml" );

        final DefaultBindings defaultBindings = 
            XML2Java.bind( parsedDocument, DefaultBindings.class ); 
        Main.printValues( defaultBindings );
    }

    private static void printValues( final DefaultBindings defaultBindings )
    {
        // X2JB default bindings are created from method names
        System.out.println( "Primitive boolean value is: " +
            defaultBindings.getBooleanPrimitive() );
        System.out.println( "Primitive byte value is: " +
            defaultBindings.getBytePrimitive() );
        System.out.println( "Primitive char value is: " +
            defaultBindings.getCharPrimitive() );
        System.out.println( "Primitive short value is: " +
            defaultBindings.getShortPrimitive() );
        System.out.println( "Primitive int value is: " +
            defaultBindings.getIntPrimitive() );
        System.out.println( "Primitive long value is: " +
            defaultBindings.getLongPrimitive() );
        System.out.println( "Primitive float value is: " +
            defaultBindings.getFloatPrimitive() );
        System.out.println( "Primitive double value is: " +
            defaultBindings.getDoublePrimitive() );
        System.out.println( "Boolean value is: " +
            defaultBindings.getBoolean() );
        System.out.println( "Byte value is: " +
            defaultBindings.getByte() );
        System.out.println( "Character value is: " +
            defaultBindings.getCharacter() );
        System.out.println( "Short value is: " +
            defaultBindings.getShort() );
        System.out.println( "Integer value is: " +
            defaultBindings.getInteger() );
        System.out.println( "Long value is: " +
            defaultBindings.getLong() );
        System.out.println( "Float value is: " +
            defaultBindings.getFloat() );
        System.out.println( "Double value is: " +
            defaultBindings.getDouble() );
        System.out.println( "String value is: " +
            defaultBindings.getString() );
        System.out.println( "QName value is: " +
            defaultBindings.getQName() );
        System.out.println( "BigInteger value is: " +
            defaultBindings.getBigInteger() );
        System.out.println( "BigDecimal value is: " +
            defaultBindings.getBigDecimal() );
    }

}
